import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:quran_library/quran_library.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await QuranLibrary.init();
  QuranLibrary.initWordAudio();
  await ReminderService.init();

  final prefs = await SharedPreferences.getInstance();
  final settings = AppSettingsController(prefs);
  await settings.load();

  runApp(QuranMushafApp(settings: settings));
}

class QuranMushafApp extends StatelessWidget {
  const QuranMushafApp({super.key, required this.settings});

  final AppSettingsController settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'مصحف بسيط',
            locale: const Locale('ar'),
            themeMode: settings.isDark ? ThemeMode.dark : ThemeMode.light,
            theme: ThemeData(
              useMaterial3: false,
              fontFamily: 'sans-serif',
              colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF75D7D0)),
            ),
            darkTheme: ThemeData(
              useMaterial3: false,
              scaffoldBackgroundColor: const Color(0xFF121212),
              colorScheme: ColorScheme.fromSeed(
                brightness: Brightness.dark,
                seedColor: const Color(0xFF75D7D0),
              ),
            ),
            home: HomeShell(settings: settings),
          ),
        );
      },
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.settings});

  final AppSettingsController settings;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _currentIndex = 0;
  bool _fullScreen = false;
  final _audioScreenKey = GlobalKey<AudioScreenState>();

  void _toggleFullScreen() {
    setState(() => _fullScreen = !_fullScreen);
    SystemChrome.setEnabledSystemUIMode(
      _fullScreen ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = <Widget>[
      QuranReaderScreen(
        settings: widget.settings,
        fullScreen: _fullScreen,
        onToggleFullScreen: _toggleFullScreen,
      ),
      AudioScreen(key: _audioScreenKey, settings: widget.settings),
      WirdScreen(settings: widget.settings),
      SettingsScreen(settings: widget.settings),
    ];

    final titles = ['المصحف', 'الاستماع', 'الورد اليومي', 'الإعدادات'];

    return Scaffold(
      appBar: _fullScreen
          ? null
          : AppBar(
              title: Text(titles[_currentIndex]),
              actions: [
                if (_currentIndex == 0)
                  IconButton(
                    tooltip: 'فول سكرين',
                    onPressed: _toggleFullScreen,
                    icon: const Icon(Icons.fullscreen),
                  ),
                if (_currentIndex == 1)
                  IconButton(
                    tooltip: 'تشغيل من آخر موضع',
                    onPressed: () => _audioScreenKey.currentState?.resume(),
                    icon: const Icon(Icons.play_circle_fill),
                  ),
              ],
            ),
      body: SafeArea(child: screens[_currentIndex]),
      bottomNavigationBar: _fullScreen
          ? null
          : BottomNavigationBar(
              currentIndex: _currentIndex,
              type: BottomNavigationBarType.fixed,
              onTap: (index) => setState(() => _currentIndex = index),
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'المصحف'),
                BottomNavigationBarItem(icon: Icon(Icons.headset), label: 'الاستماع'),
                BottomNavigationBarItem(icon: Icon(Icons.task_alt), label: 'الورد'),
                BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'الإعدادات'),
              ],
            ),
    );
  }
}

class QuranReaderScreen extends StatelessWidget {
  const QuranReaderScreen({
    super.key,
    required this.settings,
    required this.fullScreen,
    required this.onToggleFullScreen,
  });

  final AppSettingsController settings;
  final bool fullScreen;
  final VoidCallback onToggleFullScreen;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        QuranLibraryScreen(
          parentContext: context,
          withPageView: true,
          useDefaultAppBar: false,
          isShowAudioSlider: true,
          showAyahBookmarkedIcon: settings.highlightBookmarks,
          isDark: settings.isDark,
          appLanguageCode: 'ar',
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          textColor: Theme.of(context).colorScheme.onSurface,
        ),
        if (fullScreen)
          Positioned(
            left: 12,
            top: 12,
            child: FloatingActionButton.small(
              heroTag: 'close_fullscreen',
              onPressed: onToggleFullScreen,
              child: const Icon(Icons.fullscreen_exit),
            ),
          ),
        Positioned(
          right: 12,
          bottom: 12,
          child: FloatingActionButton.small(
            heroTag: 'reader_hint',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('ابحث من تبويب البحث داخل المصحف، واضغط مطولاً على الآية لخيارات النسخ والمرجع.'),
                ),
              );
            },
            child: const Icon(Icons.info_outline),
          ),
        ),
      ],
    );
  }
}

class AudioScreen extends StatefulWidget {
  const AudioScreen({super.key, required this.settings});

  final AppSettingsController settings;

  @override
  State<AudioScreen> createState() => AudioScreenState();
}

class AudioScreenState extends State<AudioScreen> {
  int _selectedSurah = 1;

  Future<void> resume() async {
    await QuranLibrary().playLastPosition();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم التشغيل من آخر موضع محفوظ.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentSurah = QuranLibrary().currentAndLastSurahNumber;
    final lastTime = QuranLibrary().formatLastPositionToTime;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _SectionCard(
          title: 'وضع الاستماع',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.settings.onlineListening
                    ? 'الوضع الحالي: استماع عبر الإنترنت.'
                    : 'الوضع الحالي: تحميل السورة أولاً ثم الاستماع بدون نت.',
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                value: _selectedSurah,
                decoration: const InputDecoration(
                  labelText: 'اختر السورة',
                  border: OutlineInputBorder(),
                ),
                items: List.generate(
                  surahNames.length,
                  (index) => DropdownMenuItem(
                    value: index + 1,
                    child: Text('${index + 1} - ${surahNames[index]}'),
                  ),
                ),
                onChanged: (value) => setState(() => _selectedSurah = value ?? 1),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.icon(
                    onPressed: () async {
                      await QuranLibrary().playSurah(surahNumber: _selectedSurah);
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('بدأ تشغيل سورة ${surahNames[_selectedSurah - 1]}.')),
                        );
                      }
                    },
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('تشغيل'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () async {
                      await QuranLibrary().startDownloadSurah(surahNumber: _selectedSurah);
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('بدأ تنزيل سورة ${surahNames[_selectedSurah - 1]}.')),
                        );
                      }
                    },
                    icon: const Icon(Icons.download_for_offline_outlined),
                    label: const Text('تحميل'),
                  ),
                  OutlinedButton.icon(
                    onPressed: resume,
                    icon: const Icon(Icons.restore),
                    label: const Text('استكمال'),
                  ),
                  TextButton.icon(
                    onPressed: () {
                      QuranLibrary().cancelDownloadSurah();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم إلغاء التنزيل الحالي.')),
                      );
                    },
                    icon: const Icon(Icons.close),
                    label: const Text('إلغاء التنزيل'),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _SectionCard(
          title: 'آخر موضع',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('آخر سورة تم تشغيلها: ${surahNames[math.max(0, currentSurah - 1)]}'),
              const SizedBox(height: 8),
              Text('آخر توقيت محفوظ: ${lastTime.isEmpty ? '00:00' : lastTime}'),
              const SizedBox(height: 12),
              const Text('ممكن تفتح شاشة المصحف نفسها وتتحكم في الصوت من داخل القراءة في الخلفية.'),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _SectionCard(
          title: 'وضع التحفيظ',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('الوضع ده مناسب للأطفال أو للحفظ: افتح السورة، شغّلها، وكرّر المقطع من شاشة القراءة.'),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  await QuranLibrary().playSurah(surahNumber: _selectedSurah);
                },
                icon: const Icon(Icons.repeat),
                label: const Text('ابدأ من السورة المختارة'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class WirdScreen extends StatelessWidget {
  const WirdScreen({super.key, required this.settings});

  final AppSettingsController settings;

  @override
  Widget build(BuildContext context) {
    final startPage = settings.wirdStartPage;
    final endPage = math.min(604, startPage + settings.pagesPerDay - 1);

    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        final start = settings.wirdStartPage;
        final end = math.min(604, start + settings.pagesPerDay - 1);
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _SectionCard(
              title: 'خطة الورد',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('عدد الصفحات يومياً: ${settings.pagesPerDay}'),
                  Slider(
                    min: 1,
                    max: 20,
                    divisions: 19,
                    value: settings.pagesPerDay.toDouble(),
                    onChanged: (value) => settings.setPagesPerDay(value.round()),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Chip(
                        backgroundColor: Colors.teal.withOpacity(.15),
                        label: Text('أول صفحة: $start'),
                      ),
                      Chip(
                        backgroundColor: Colors.orange.withOpacity(.15),
                        label: Text('آخر صفحة: $end'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: start > 1
                              ? () => settings.setWirdStartPage(math.max(1, start - settings.pagesPerDay))
                              : null,
                          icon: const Icon(Icons.chevron_right),
                          label: const Text('السابق'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: end >= 604
                              ? null
                              : () => settings.setWirdStartPage(math.min(604, start + settings.pagesPerDay)),
                          icon: const Icon(Icons.chevron_left),
                          label: const Text('التالي'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'تذكير يومي',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('وقت التذكير'),
                    subtitle: Text(settings.formattedReminderTime),
                    trailing: const Icon(Icons.alarm),
                    onTap: () async {
                      final picked = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay(hour: settings.reminderHour, minute: settings.reminderMinute),
                        builder: (context, child) => Directionality(
                          textDirection: TextDirection.rtl,
                          child: child!,
                        ),
                      );
                      if (picked != null) {
                        await settings.setReminderTime(picked.hour, picked.minute);
                        await ReminderService.scheduleDailyWird(
                          hour: picked.hour,
                          minute: picked.minute,
                          startPage: settings.wirdStartPage,
                          endPage: math.min(604, settings.wirdStartPage + settings.pagesPerDay - 1),
                        );
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('تم حفظ التذكير اليومي.')),
                          );
                        }
                      }
                    },
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: () async {
                          await ReminderService.scheduleDailyWird(
                            hour: settings.reminderHour,
                            minute: settings.reminderMinute,
                            startPage: settings.wirdStartPage,
                            endPage: math.min(604, settings.wirdStartPage + settings.pagesPerDay - 1),
                          );
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('تم تفعيل التذكير اليومي للورد.')),
                            );
                          }
                        },
                        icon: const Icon(Icons.notifications_active_outlined),
                        label: const Text('تفعيل التذكير'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () async {
                          await ReminderService.cancel();
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('تم إلغاء التذكير اليومي.')),
                            );
                          }
                        },
                        icon: const Icon(Icons.notifications_off_outlined),
                        label: const Text('إلغاء التذكير'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'عرض الورد',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('الزرار ده بيفتح صفحات وردك الحالي بشكل مباشر.'),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => WirdPagesViewer(
                            startPage: settings.wirdStartPage,
                            endPage: math.min(604, settings.wirdStartPage + settings.pagesPerDay - 1),
                            isDark: settings.isDark,
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.auto_stories_outlined),
                    label: const Text('افتح الورد الآن'),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class WirdPagesViewer extends StatelessWidget {
  const WirdPagesViewer({
    super.key,
    required this.startPage,
    required this.endPage,
    required this.isDark,
  });

  final int startPage;
  final int endPage;
  final bool isDark;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ورد اليوم: من $startPage إلى $endPage'),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(.4),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(
                  backgroundColor: Colors.teal.withOpacity(.15),
                  label: Text('بداية الورد: صفحة $startPage'),
                ),
                Chip(
                  backgroundColor: Colors.orange.withOpacity(.15),
                  label: Text('نهاية الورد: صفحة $endPage'),
                ),
              ],
            ),
          ),
          Expanded(
            child: QuranPagesScreen(
              parentContext: context,
              startPage: startPage,
              endPage: endPage,
              withPageView: true,
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.settings});

  final AppSettingsController settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _SectionCard(
              title: 'إعدادات العرض',
              child: Column(
                children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: settings.isDark,
                    onChanged: settings.setDarkMode,
                    title: const Text('الوضع الليلي'),
                    subtitle: const Text('خلفية داكنة مع شكل بسيط وواضح.'),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: settings.showArabicMode,
                    onChanged: settings.setArabicMode,
                    title: const Text('الوضع العربي'),
                    subtitle: const Text('تثبيت العربية كلغة أساسية للتطبيق.'),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: settings.showPageInfo,
                    onChanged: settings.setShowPageInfo,
                    title: const Text('عرض بيانات الصفحة'),
                    subtitle: const Text('رقم الصفحة واسم السورة والجزء أثناء القراءة.'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'التفسير والترجمة',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('حجم خط الآيات: ${settings.ayahFontSize.round()}'),
                  Slider(
                    value: settings.ayahFontSize,
                    min: 16,
                    max: 34,
                    divisions: 18,
                    onChanged: settings.setAyahFontSize,
                  ),
                  const SizedBox(height: 8),
                  Text('حجم خط التفسير والترجمة: ${settings.tafsirFontSize.round()}'),
                  Slider(
                    value: settings.tafsirFontSize,
                    min: 12,
                    max: 28,
                    divisions: 16,
                    onChanged: settings.setTafsirFontSize,
                  ),
                  const SizedBox(height: 8),
                  const Text('التغيير هنا محفوظ للتخصيص العام، وشاشة المصحف نفسها فيها التفسير والبحث والعلامات المرجعية.'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'الصوت والتحمــيل',
              child: Column(
                children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: settings.onlineListening,
                    onChanged: settings.setOnlineListening,
                    title: const Text('استماع عبر الإنترنت'),
                    subtitle: const Text('لو قفلتها يبقى الأفضل تحمّل السورة أولاً للاستخدام بدون نت.'),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: settings.highlightBookmarks,
                    onChanged: settings.setHighlightBookmarks,
                    title: const Text('تعليم المرجعيات'),
                    subtitle: const Text('إظهار العلامات المرجعية داخل القراءة.'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _SectionCard(
              title: 'حول التطبيق',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.android),
                    title: Text('نسخة مبدئية مناسبة لبدء مشروع Android / Flutter'),
                    subtitle: Text('واجهة عربية بسيطة + مصحف + صوت + ورد يومي + وضع ليلي.'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () {
                      showAboutDialog(
                        context: context,
                        applicationName: 'مصحف بسيط',
                        applicationVersion: '1.0.0',
                        applicationLegalese: 'نسخة أولية مطورة لتكون نقطة بداية سهلة للتحويل إلى APK.',
                      );
                    },
                    icon: const Icon(Icons.info_outline),
                    label: const Text('معلومات الإصدار'),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: Theme.of(context).colorScheme.primary,
                  ),
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class AppSettingsController extends ChangeNotifier {
  AppSettingsController(this._prefs);

  final SharedPreferences _prefs;

  bool isDark = true;
  bool onlineListening = true;
  bool showPageInfo = true;
  bool highlightBookmarks = true;
  bool showArabicMode = true;
  double ayahFontSize = 24;
  double tafsirFontSize = 18;
  int pagesPerDay = 4;
  int wirdStartPage = 1;
  int reminderHour = 20;
  int reminderMinute = 0;

  Future<void> load() async {
    isDark = _prefs.getBool('isDark') ?? true;
    onlineListening = _prefs.getBool('onlineListening') ?? true;
    showPageInfo = _prefs.getBool('showPageInfo') ?? true;
    highlightBookmarks = _prefs.getBool('highlightBookmarks') ?? true;
    showArabicMode = _prefs.getBool('showArabicMode') ?? true;
    ayahFontSize = _prefs.getDouble('ayahFontSize') ?? 24;
    tafsirFontSize = _prefs.getDouble('tafsirFontSize') ?? 18;
    pagesPerDay = _prefs.getInt('pagesPerDay') ?? 4;
    wirdStartPage = _prefs.getInt('wirdStartPage') ?? 1;
    reminderHour = _prefs.getInt('reminderHour') ?? 20;
    reminderMinute = _prefs.getInt('reminderMinute') ?? 0;
    notifyListeners();
  }

  String get formattedReminderTime {
    final h = reminderHour.toString().padLeft(2, '0');
    final m = reminderMinute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  Future<void> setDarkMode(bool value) async {
    isDark = value;
    await _prefs.setBool('isDark', value);
    notifyListeners();
  }

  Future<void> setOnlineListening(bool value) async {
    onlineListening = value;
    await _prefs.setBool('onlineListening', value);
    notifyListeners();
  }

  Future<void> setShowPageInfo(bool value) async {
    showPageInfo = value;
    await _prefs.setBool('showPageInfo', value);
    notifyListeners();
  }

  Future<void> setHighlightBookmarks(bool value) async {
    highlightBookmarks = value;
    await _prefs.setBool('highlightBookmarks', value);
    notifyListeners();
  }

  Future<void> setArabicMode(bool value) async {
    showArabicMode = value;
    await _prefs.setBool('showArabicMode', value);
    notifyListeners();
  }

  Future<void> setAyahFontSize(double value) async {
    ayahFontSize = value;
    await _prefs.setDouble('ayahFontSize', value);
    notifyListeners();
  }

  Future<void> setTafsirFontSize(double value) async {
    tafsirFontSize = value;
    await _prefs.setDouble('tafsirFontSize', value);
    notifyListeners();
  }

  Future<void> setPagesPerDay(int value) async {
    pagesPerDay = value;
    await _prefs.setInt('pagesPerDay', value);
    notifyListeners();
  }

  Future<void> setWirdStartPage(int value) async {
    wirdStartPage = value.clamp(1, 604);
    await _prefs.setInt('wirdStartPage', wirdStartPage);
    notifyListeners();
  }

  Future<void> setReminderTime(int hour, int minute) async {
    reminderHour = hour;
    reminderMinute = minute;
    await _prefs.setInt('reminderHour', hour);
    await _prefs.setInt('reminderMinute', minute);
    notifyListeners();
  }
}

class ReminderService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tz.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Africa/Cairo'));

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);

    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> scheduleDailyWird({
    required int hour,
    required int minute,
    required int startPage,
    required int endPage,
  }) async {
    await cancel();

    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }

    await _plugin.zonedSchedule(
      101,
      'تذكير الورد اليومي',
      'وردك اليوم من صفحة $startPage إلى صفحة $endPage',
      scheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_wird_channel',
          'التذكير اليومي',
          channelDescription: 'تنبيهات الورد اليومي داخل تطبيق المصحف',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> cancel() async {
    await _plugin.cancel(101);
  }
}

const List<String> surahNames = [
  'الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس',
  'هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه',
  'الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم',
  'لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر',
  'فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق',
  'الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة',
  'الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج',
  'نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس',
  'التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد',
  'الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات',
  'القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر',
  'المسد','الإخلاص','الفلق','الناس'
];
