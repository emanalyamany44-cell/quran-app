package com.example.quran_mushaf_flutter_starter

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity: AudioServiceActivity()
